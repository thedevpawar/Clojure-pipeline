(ns pipeline
  "Integrated data pipeline:
   1. Sequence functions and transducers over an order dataset
   2. Ring/Jetty HTTP endpoints serving the results
   3. SQLite persistence via next.jdbc with try/catch error handling
   4. Java interop (java.time, System/exit)

   Run the server:  lein run
   Run the tests:   lein run test"
  (:require [clojure.test :refer [deftest is run-tests]]
            [next.jdbc :as jdbc]
            [next.jdbc.sql :as sql]
            [next.jdbc.result-set :as rs]
            [ring.adapter.jetty :refer [run-jetty]]
            [ring.util.response :as resp]
            [cheshire.core :as json])
  (:import (java.time LocalDate)
           (java.time.format DateTimeParseException))
  (:gen-class))

;; =============================================================================
;; 1. Dataset and pure processing (sequence functions, transducers, interop)
;; =============================================================================

(def raw-orders
  [{:id 1  :customer "Asha"  :category "books"       :qty 2  :unit-price 350.0  :date "2026-01-05"}
   {:id 2  :customer "Ravi"  :category "games"       :qty 1  :unit-price 2500.0 :date "2026-01-07"}
   {:id 3  :customer "Meera" :category "books"       :qty 0  :unit-price 120.0  :date "2026-01-09"} ; invalid qty
   {:id 4  :customer "Kiran" :category "stationery"  :qty 10 :unit-price 15.5   :date "2026-02-01"}
   {:id 5  :customer "Dev"   :category "games"       :qty 3  :unit-price -40.0  :date "2026-02-03"} ; invalid price
   {:id 6  :customer "Priya" :category "books"       :qty 1  :unit-price 499.0  :date "2026-02-14"}
   {:id 7  :customer "Arjun" :category "stationery"  :qty 4  :unit-price 80.0   :date "2026-13-40"} ; invalid date
   {:id 8  :customer "Nisha" :category "games"       :qty 2  :unit-price 1200.0 :date "2026-03-02"}
   {:id 9  :customer "Sam"   :category "books"       :qty 5  :unit-price 275.0  :date "2026-03-18"}
   {:id 10 :customer "Tara"  :category "stationery"  :qty 20 :unit-price 12.0   :date "2026-03-25"}])

(defn parse-date
  "Parses an ISO-8601 date with java.time.LocalDate. Returns nil when invalid."
  [s]
  (when (string? s)
    (try
      (LocalDate/parse s)
      (catch DateTimeParseException _ nil))))

(defn valid-order? [{:keys [qty unit-price date]}]
  (and (pos? qty)
       (pos? unit-price)
       (some? (parse-date date))))

(defn with-total [{:keys [qty unit-price] :as order}]
  (assoc order :total (* qty unit-price)))

(def order-xf
  "Transducer: keep valid orders and attach :total in one pass."
  (comp (filter valid-order?)
        (map with-total)))

(defn process-orders
  "Returns the valid orders with :total added."
  [orders]
  (into [] order-xf orders))

(defn total-revenue
  "Sum of totals for valid orders."
  [orders]
  (transduce (comp order-xf (map :total)) + 0.0 orders))

(defn category-summary
  "Reduces processed orders to {category {:orders n :revenue x}}."
  [orders]
  (reduce (fn [acc {:keys [category total]}]
            (update acc category
                    (fn [{:keys [orders revenue] :or {orders 0 revenue 0.0}}]
                      {:orders  (inc orders)
                       :revenue (+ revenue total)})))
          {}
          orders))

;; =============================================================================
;; 2. Database layer (SQLite via next.jdbc, try/catch error handling)
;; =============================================================================

(def ds (jdbc/get-datasource {:dbtype "sqlite" :dbname "pipeline.db"}))

(defn- db-error
  "Wraps a low-level exception in an ex-info tagged ::db-error."
  [msg cause]
  (ex-info msg {:type ::db-error} cause))

(defn init-db!
  "Creates the orders table if it does not exist."
  []
  (try
    (jdbc/execute! ds ["CREATE TABLE IF NOT EXISTS orders (
                          id          INTEGER PRIMARY KEY,
                          customer    TEXT NOT NULL,
                          category    TEXT NOT NULL,
                          qty         INTEGER NOT NULL,
                          unit_price  REAL NOT NULL,
                          total       REAL NOT NULL,
                          order_date  TEXT NOT NULL)"])
    :ok
    (catch Exception e
      (throw (db-error "Could not create schema" e)))))

(defn- ->row [o]
  {:id         (:id o)
   :customer   (:customer o)
   :category   (:category o)
   :qty        (:qty o)
   :unit_price (:unit-price o)
   :total      (:total o)
   :order_date (:date o)})

(defn save-orders!
  "Replaces the table contents atomically. Returns the number of rows written.
   The transaction rolls back automatically if any insert fails."
  [orders]
  (try
    (jdbc/with-transaction [tx ds]
      (jdbc/execute! tx ["DELETE FROM orders"])
      (doseq [o orders]
        (sql/insert! tx :orders (->row o)))
      (count orders))
    (catch Exception e
      (throw (db-error "Could not save orders (rolled back)" e)))))

(defn all-orders
  "Reads all orders from the database as unqualified lower-case maps."
  []
  (try
    (jdbc/execute! ds ["SELECT id, customer, category, qty, unit_price, total, order_date
                        FROM orders ORDER BY order_date"]
                   {:builder-fn rs/as-unqualified-lower-maps})
    (catch Exception e
      (throw (db-error "Could not read orders" e)))))

;; =============================================================================
;; 3. HTTP layer (Ring + Jetty)
;; =============================================================================

(defn- json-resp [status body]
  (-> (resp/response (json/generate-string body))
      (resp/status status)
      (resp/content-type "application/json")))

(defn- route [{:keys [request-method uri]}]
  (cond
    (and (= :get request-method) (= "/orders" uri))
    (json-resp 200 (all-orders))

    (and (= :get request-method) (= "/summary" uri))
    (json-resp 200 (category-summary (all-orders)))

    :else
    (json-resp 404 {:error "not found"})))

(defn app
  "Ring handler. Database failures become 503; anything else becomes 500."
  [req]
  (try
    (route req)
    (catch clojure.lang.ExceptionInfo e
      (if (= ::db-error (:type (ex-data e)))
        (json-resp 503 {:error (ex-message e)})
        (json-resp 500 {:error "internal error"})))
    (catch Exception _
      (json-resp 500 {:error "internal error"}))))

(defn start-server!
  "Starts Jetty on the given port without blocking."
  [port]
  (run-jetty app {:port port :join? false}))

;; =============================================================================
;; 4. Tests
;; =============================================================================

(deftest filters-invalid-rows
  (is (= 7 (count (process-orders raw-orders)))))

(deftest total-revenue-is-correct
  (is (= 7869.0 (total-revenue raw-orders))))

(deftest category-summary-groups-correctly
  (let [s (category-summary (process-orders raw-orders))]
    (is (= {:orders 3 :revenue 2574.0} (s "books")))
    (is (= {:orders 2 :revenue 4900.0} (s "games")))
    (is (= {:orders 2 :revenue 395.0}  (s "stationery")))))

(deftest bad-date-is-rejected
  (is (nil? (parse-date "2026-13-40"))))

;; =============================================================================
;; 5. Entry point
;; =============================================================================

(defn -main
  "`lein run`      -> process data, persist to SQLite, start server on :3000
   `lein run test` -> run unit tests"
  [& args]
  (if (= ["test"] (vec args))
    (let [{:keys [fail error]} (run-tests 'pipeline)]
      (System/exit (if (zero? (+ fail error)) 0 1)))
    (let [processed (process-orders raw-orders)]
      (println "Valid:" (count processed)
               "| Rejected:" (- (count raw-orders) (count processed)))
      (println "Total revenue:" (total-revenue raw-orders))
      (try
        (init-db!)
        (println "Saved rows:" (save-orders! processed))
        (catch Exception e
          (println "Database step failed:" (ex-message e))
          (println "Cause:" (some-> (ex-cause e) ex-message))
          (System/exit 1)))
      (start-server! 3000)
      (println "Serving on http://localhost:3000  (GET /orders, GET /summary)"))))
