# Clojure Data Pipeline (Sessions 10–11)

A single integrated application covering:

1. **Sequence functions and transducers** — `filter`, `map`, `reduce`, `transduce`, `into` over an order dataset (`src/pipeline.clj`).
2. **Ring HTTP endpoints** — `GET /orders` and `GET /summary` served by Jetty.
3. **Relational database** — SQLite via `next.jdbc`, with `try/catch` and transaction rollback.
4. **Java interop** — `java.time.LocalDate` for date validation, `System/exit` for exit codes.

## Requirements

- JDK 11 or newer
- Leiningen 2.9+ (https://leiningen.org)

## Run

```bash
cd clojure-pipeline

lein deps          # download dependencies (first time only)
lein test          # run unit tests
lein run           # create pipeline.db, load orders, start server on :3000
```

In a second terminal:

```bash
curl http://localhost:3000/orders
curl http://localhost:3000/summary
curl http://localhost:3000/nope     # 404 example
```

Stop the server with Ctrl+C.

## Expected output

`lein run` prints:

```
Valid: 7 | Rejected: 3
Total revenue: 7869.0
Saved rows: 7
Serving on http://localhost:3000  (GET /orders, GET /summary)
```

`/summary` returns:

```json
{"books":{"orders":3,"revenue":2574.0},"games":{"orders":2,"revenue":4900.0},"stationery":{"orders":2,"revenue":395.0}}
```

## Project layout

```
clojure-pipeline/
├── project.clj        Leiningen project and dependencies
├── README.md          this file
├── .gitignore
└── src/
    └── pipeline.clj   all source: data, processing, DB, HTTP, tests, entry point
```

## Notes

- The database file `pipeline.db` is created in the working directory on first run. `save-orders!` replaces the table contents on every run, so re-running is safe.
- Invalid rows (zero quantity, negative price, impossible date) are filtered out by the transducer and counted as rejected.
