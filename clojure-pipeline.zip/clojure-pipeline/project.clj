(defproject clojure-pipeline "0.1.0"
  :description "Data pipeline: sequences, transducers, Ring, JDBC (SQLite)"
  :dependencies [[org.clojure/clojure "1.11.1"]
                 [ring/ring-core "1.12.2"]
                 [ring/ring-jetty-adapter "1.12.2"]
                 [cheshire "5.13.0"]
                 [com.github.seancorfield/next.jdbc "1.3.939"]
                 [org.xerial/sqlite-jdbc "3.46.0.0"]]
  :main pipeline
  :aot [pipeline])
